class Entry:
    # represent an entry in the symbol table
    # superclass for Constant and Variable
    def __init__(self):
        pass
