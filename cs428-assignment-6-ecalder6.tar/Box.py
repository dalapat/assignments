class Box:
    def __init__(self):
        self.token = None

    def __str__(self):
        return "Box"