class Node:
    def __init__(self):
        self.token = None

    def __str__(self):
        return "Node"