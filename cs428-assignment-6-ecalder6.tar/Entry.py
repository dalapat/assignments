class Entry:
    def __str__(self):
        return "Entry"