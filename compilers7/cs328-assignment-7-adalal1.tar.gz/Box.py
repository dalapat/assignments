class Box(object):

    def __init__(self):
        pass