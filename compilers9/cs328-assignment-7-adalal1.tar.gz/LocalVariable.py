from Variable import Variable

class LocalVariable(Variable):

    def __init__(self, _type):
        Variable.__init__(self, _type)