from Variable import Variable

class FormalVariable(Variable):

    def __init__(self, _type):
        Variable.__init__(self, _type)