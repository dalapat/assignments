for line in eachline(STDIN)
    write(line)
end 