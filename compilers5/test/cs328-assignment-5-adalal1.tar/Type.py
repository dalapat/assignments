from Entry import Entry

class Type(Entry):
    # superclass of Array, Integer, Record

    def __init__(self):
        pass

